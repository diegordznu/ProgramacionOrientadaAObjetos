
from conexionBD import conexion, cursor
class Autos:
    @staticmethod
    def consultar():
        try:
            cursor.execute("SELECT * FROM coches")
            return cursor.fetchall()
        except:
            return []